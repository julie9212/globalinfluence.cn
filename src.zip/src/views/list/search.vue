<template>
    <div >
        123123123
    </div>
</template>

<script>

// import About from '../components/about/form'
// import Ad from '../components/list/ad'

export default {
    // components:{
    //     About,
    //     Ad
    // },
    data() {
        return {
        }
    },   
    mounted() {
        
    },
 methods: {
        
    },
}
</script>

<style lang="less" scoped>

</style>
